"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const seo_score_1 = require("../../../lib/seo-score");
const locale_overlay_1 = require("./locale-overlay");
/**
 * SEO score for every published product, worst first.
 *
 * Scoring is pure and costs ~3ms per product, so the whole catalogue is graded
 * per request rather than cached — a stale score is worse than a one-second
 * wait, and there is no invalidation to get wrong.
 */
const PAGE = 200;
/** Stop paging a runaway catalogue rather than hanging the admin. */
const MAX_PRODUCTS = 2000;
const PRODUCT_FIELDS = ["id", "title", "handle", "description", "metadata", "images.*"];
async function GET(req, res) {
    const config = (0, seo_score_1.loadConfig)();
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const search = String(req.query.q ?? "").trim().toLowerCase();
    const limit = Math.min(Math.max(parseInt(String(req.query.limit ?? "100"), 10) || 100, 1), 500);
    const products = [];
    let offset = 0;
    let total = 0;
    do {
        const { data, metadata } = await query.graph({
            entity: "product",
            fields: PRODUCT_FIELDS,
            filters: { status: "published" },
            pagination: { take: PAGE, skip: offset },
        });
        products.push(...data);
        total = metadata?.count ?? products.length;
        offset += PAGE;
    } while (products.length < total && products.length < MAX_PRODUCTS);
    const locale = (0, seo_score_1.normaliseLocale)(req.query.locale, config);
    const matched = products.filter((p) => {
        if (!search)
            return true;
        return `${p.title ?? ""} ${p.handle ?? ""}`.toLowerCase().includes(search);
    });
    const overlays = await (0, locale_overlay_1.loadLocaleOverlays)(req.scope, matched.map((p) => p.id), locale, config);
    const scored = matched
        .map((p) => (0, seo_score_1.scoreProduct)(p, overlays[p.id] ?? {}, locale, config))
        .sort((a, b) => a.score - b.score || a.title.localeCompare(b.title));
    const { groups, bands, ui } = (0, seo_score_1.labelsFor)(config.lang);
    res.json({
        locale,
        locales: config.locales,
        // The admin needs this to know which locale owns the editable fields.
        source_locale: config.sourceLocale,
        labels: { groups, bands, ui },
        scores: scored.slice(0, limit).map(({ checks, ...row }) => row),
        count: scored.length,
        scanned: products.length,
        average: scored.length
            ? Math.round(scored.reduce((sum, s) => sum + s.score, 0) / scored.length)
            : 0,
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3Nlby1zY29yZS9yb3V0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQTBCQSxrQkFxREM7QUE5RUQscURBQXFFO0FBQ3JFLHNEQU8rQjtBQUMvQixxREFBcUQ7QUFFckQ7Ozs7OztHQU1HO0FBRUgsTUFBTSxJQUFJLEdBQUcsR0FBRyxDQUFBO0FBQ2hCLHFFQUFxRTtBQUNyRSxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUE7QUFFekIsTUFBTSxjQUFjLEdBQUcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxhQUFhLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFBO0FBRWhGLEtBQUssVUFBVSxHQUFHLENBQUMsR0FBa0IsRUFBRSxHQUFtQjtJQUMvRCxNQUFNLE1BQU0sR0FBRyxJQUFBLHNCQUFVLEdBQUUsQ0FBQTtJQUMzQixNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxpQ0FBeUIsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUNoRSxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFLENBQUE7SUFDN0QsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLElBQUksS0FBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUksR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFBO0lBRS9GLE1BQU0sUUFBUSxHQUF1QixFQUFFLENBQUE7SUFDdkMsSUFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFBO0lBQ2QsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFBO0lBRWIsR0FBRyxDQUFDO1FBQ0YsTUFBTSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsR0FBRyxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDM0MsTUFBTSxFQUFFLFNBQVM7WUFDakIsTUFBTSxFQUFFLGNBQWM7WUFDdEIsT0FBTyxFQUFFLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRTtZQUNoQyxVQUFVLEVBQUUsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUU7U0FDekMsQ0FBQyxDQUFBO1FBQ0YsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFJLElBQTJCLENBQUMsQ0FBQTtRQUM5QyxLQUFLLEdBQUcsUUFBUSxFQUFFLEtBQUssSUFBSSxRQUFRLENBQUMsTUFBTSxDQUFBO1FBQzFDLE1BQU0sSUFBSSxJQUFJLENBQUE7SUFDaEIsQ0FBQyxRQUFRLFFBQVEsQ0FBQyxNQUFNLEdBQUcsS0FBSyxJQUFJLFFBQVEsQ0FBQyxNQUFNLEdBQUcsWUFBWSxFQUFDO0lBRW5FLE1BQU0sTUFBTSxHQUFHLElBQUEsMkJBQWUsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQTtJQUN4RCxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUU7UUFDcEMsSUFBSSxDQUFDLE1BQU07WUFBRSxPQUFPLElBQUksQ0FBQTtRQUN4QixPQUFPLEdBQUcsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLE1BQU0sSUFBSSxFQUFFLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDNUUsQ0FBQyxDQUFDLENBQUE7SUFDRixNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUEsbUNBQWtCLEVBQ3ZDLEdBQUcsQ0FBQyxLQUFLLEVBQ1QsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUN4QixNQUFNLEVBQ04sTUFBTSxDQUNQLENBQUE7SUFFRCxNQUFNLE1BQU0sR0FBbUIsT0FBTztTQUNuQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLElBQUEsd0JBQVksRUFBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1NBQ2pFLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQTtJQUV0RSxNQUFNLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsR0FBRyxJQUFBLHFCQUFTLEVBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFBO0lBRXBELEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDUCxNQUFNO1FBQ04sT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO1FBQ3ZCLHNFQUFzRTtRQUN0RSxhQUFhLEVBQUUsTUFBTSxDQUFDLFlBQVk7UUFDbEMsTUFBTSxFQUFFLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUU7UUFDN0IsTUFBTSxFQUFFLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsTUFBTSxFQUFFLEdBQUcsR0FBRyxFQUFFLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQztRQUMvRCxLQUFLLEVBQUUsTUFBTSxDQUFDLE1BQU07UUFDcEIsT0FBTyxFQUFFLFFBQVEsQ0FBQyxNQUFNO1FBQ3hCLE9BQU8sRUFBRSxNQUFNLENBQUMsTUFBTTtZQUNwQixDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQztZQUN6RSxDQUFDLENBQUMsQ0FBQztLQUNOLENBQUMsQ0FBQTtBQUNKLENBQUMifQ==