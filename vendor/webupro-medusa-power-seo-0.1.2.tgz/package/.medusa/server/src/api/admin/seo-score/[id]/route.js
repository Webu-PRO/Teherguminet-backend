"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GET = GET;
const utils_1 = require("@medusajs/framework/utils");
const seo_score_1 = require("../../../../lib/seo-score");
const locale_overlay_1 = require("../locale-overlay");
/** Full SEO score for one product in one locale, with the per-check breakdown. */
async function GET(req, res) {
    const config = (0, seo_score_1.loadConfig)();
    const query = req.scope.resolve(utils_1.ContainerRegistrationKeys.QUERY);
    const id = String(req.params.id ?? "");
    const locale = (0, seo_score_1.normaliseLocale)(req.query.locale, config);
    const { data } = await query.graph({
        entity: "product",
        fields: ["id", "title", "handle", "description", "metadata", "images.*"],
        filters: { id },
    });
    const product = data[0];
    if (!product) {
        res.status(404).json({ message: "Product not found." });
        return;
    }
    const overlays = await (0, locale_overlay_1.loadLocaleOverlays)(req.scope, [product.id], locale, config);
    const { groups, bands, ui } = (0, seo_score_1.labelsFor)(config.lang);
    res.json({
        locale,
        locales: config.locales,
        // The admin needs this to know which locale owns the editable fields.
        source_locale: config.sourceLocale,
        labels: { groups, bands, ui },
        score: (0, seo_score_1.scoreProduct)(product, overlays[product.id] ?? {}, locale, config),
    });
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3Nlby1zY29yZS9baWRdL3JvdXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBWUEsa0JBNkJDO0FBeENELHFEQUFxRTtBQUNyRSx5REFNa0M7QUFDbEMsc0RBQXNEO0FBRXRELGtGQUFrRjtBQUMzRSxLQUFLLFVBQVUsR0FBRyxDQUFDLEdBQWtCLEVBQUUsR0FBbUI7SUFDL0QsTUFBTSxNQUFNLEdBQUcsSUFBQSxzQkFBVSxHQUFFLENBQUE7SUFDM0IsTUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsaUNBQXlCLENBQUMsS0FBSyxDQUFDLENBQUE7SUFDaEUsTUFBTSxFQUFFLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO0lBQ3RDLE1BQU0sTUFBTSxHQUFHLElBQUEsMkJBQWUsRUFBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQTtJQUV4RCxNQUFNLEVBQUUsSUFBSSxFQUFFLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUFDO1FBQ2pDLE1BQU0sRUFBRSxTQUFTO1FBQ2pCLE1BQU0sRUFBRSxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLGFBQWEsRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDO1FBQ3hFLE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRTtLQUNoQixDQUFDLENBQUE7SUFFRixNQUFNLE9BQU8sR0FBSSxJQUEyQixDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQy9DLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNiLEdBQUcsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLENBQUMsQ0FBQTtRQUN2RCxPQUFNO0lBQ1IsQ0FBQztJQUVELE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBQSxtQ0FBa0IsRUFBQyxHQUFHLENBQUMsS0FBSyxFQUFFLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQTtJQUNsRixNQUFNLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUUsR0FBRyxJQUFBLHFCQUFTLEVBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFBO0lBRXBELEdBQUcsQ0FBQyxJQUFJLENBQUM7UUFDUCxNQUFNO1FBQ04sT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO1FBQ3ZCLHNFQUFzRTtRQUN0RSxhQUFhLEVBQUUsTUFBTSxDQUFDLFlBQVk7UUFDbEMsTUFBTSxFQUFFLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxFQUFFLEVBQUU7UUFDN0IsS0FBSyxFQUFFLElBQUEsd0JBQVksRUFBQyxPQUFPLEVBQUUsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQztLQUN6RSxDQUFDLENBQUE7QUFDSixDQUFDIn0=