"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.loadLocaleOverlays = loadLocaleOverlays;
const seo_score_1 = require("../../../lib/seo-score");
/** Awilix throws on an unregistered key, so absence is a catch, not a null. */
const resolveTranslations = (scope, moduleName) => {
    try {
        const service = scope.resolve(moduleName);
        return typeof service?.listTranslations === "function" ? service : null;
    }
    catch {
        return null;
    }
};
/**
 * Translated SEO fields for a set of products, as `{ [productId]: overlay }`.
 *
 * The source locale has no overlay by definition — its copy is the product row
 * — so it short-circuits without touching the translations module at all.
 */
async function loadLocaleOverlays(scope, productIds, locale, config) {
    if (locale === config.sourceLocale || productIds.length === 0)
        return {};
    const service = resolveTranslations(scope, config.translationsModule);
    if (!service)
        return {};
    const rows = await service.listTranslations({
        resource_type: "product",
        resource_id: productIds,
        locale,
        field: [...seo_score_1.SEO_TRANSLATABLE_FIELDS],
    }, 
    // One row per (product, field) at most, so this cannot exceed the product
    // count times the field count.
    { take: productIds.length * seo_score_1.SEO_TRANSLATABLE_FIELDS.length });
    const overlays = {};
    for (const row of rows) {
        ;
        (overlays[row.resource_id] ??= {})[row.field] = row.value;
    }
    return overlays;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9jYWxlLW92ZXJsYXkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9zcmMvYXBpL2FkbWluL3Nlby1zY29yZS9sb2NhbGUtb3ZlcmxheS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOztBQW1EQSxnREE0QkM7QUE5RUQsc0RBQWdFO0FBK0JoRSwrRUFBK0U7QUFDL0UsTUFBTSxtQkFBbUIsR0FBRyxDQUMxQixLQUFZLEVBQ1osVUFBa0IsRUFDVSxFQUFFO0lBQzlCLElBQUksQ0FBQztRQUNILE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFvQyxDQUFBO1FBQzVFLE9BQU8sT0FBTyxPQUFPLEVBQUUsZ0JBQWdCLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQTtJQUN6RSxDQUFDO0lBQUMsTUFBTSxDQUFDO1FBQ1AsT0FBTyxJQUFJLENBQUE7SUFDYixDQUFDO0FBQ0gsQ0FBQyxDQUFBO0FBRUQ7Ozs7O0dBS0c7QUFDSSxLQUFLLFVBQVUsa0JBQWtCLENBQ3RDLEtBQVksRUFDWixVQUFvQixFQUNwQixNQUFjLEVBQ2QsTUFBc0I7SUFFdEIsSUFBSSxNQUFNLEtBQUssTUFBTSxDQUFDLFlBQVksSUFBSSxVQUFVLENBQUMsTUFBTSxLQUFLLENBQUM7UUFBRSxPQUFPLEVBQUUsQ0FBQTtJQUV4RSxNQUFNLE9BQU8sR0FBRyxtQkFBbUIsQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLGtCQUFrQixDQUFDLENBQUE7SUFDckUsSUFBSSxDQUFDLE9BQU87UUFBRSxPQUFPLEVBQUUsQ0FBQTtJQUV2QixNQUFNLElBQUksR0FBRyxNQUFNLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FDekM7UUFDRSxhQUFhLEVBQUUsU0FBUztRQUN4QixXQUFXLEVBQUUsVUFBVTtRQUN2QixNQUFNO1FBQ04sS0FBSyxFQUFFLENBQUMsR0FBRyxtQ0FBdUIsQ0FBQztLQUNwQztJQUNELDBFQUEwRTtJQUMxRSwrQkFBK0I7SUFDL0IsRUFBRSxJQUFJLEVBQUUsVUFBVSxDQUFDLE1BQU0sR0FBRyxtQ0FBdUIsQ0FBQyxNQUFNLEVBQUUsQ0FDN0QsQ0FBQTtJQUVELE1BQU0sUUFBUSxHQUFrQyxFQUFFLENBQUE7SUFDbEQsS0FBSyxNQUFNLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUN2QixDQUFDO1FBQUEsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLENBQUMsS0FBSyxDQUFBO0lBQzVELENBQUM7SUFDRCxPQUFPLFFBQVEsQ0FBQTtBQUNqQixDQUFDIn0=