import { jsx, jsxs } from "react/jsx-runtime";
import { Component, useState, useCallback, useEffect } from "react";
import { defineWidgetConfig, defineRouteConfig } from "@medusajs/admin-sdk";
import { Container, Heading, Text, Label, Input, Button, toast, Table, Badge } from "@medusajs/ui";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ChartBar } from "@medusajs/icons";
import "@medusajs/admin-shared";
const adminQueryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 3e4,
      refetchOnWindowFocus: false
    }
  }
});
const AdminQueryProvider = ({ children }) => /* @__PURE__ */ jsx(QueryClientProvider, { client: adminQueryClient, children });
class WidgetBoundary extends Component {
  constructor() {
    super(...arguments);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error) {
    console.error(
      `[admin widget "${this.props.label}"] render error:`,
      error
    );
  }
  render() {
    if (this.state.error) {
      const err = this.state.error;
      const message = err && typeof err.message === "string" && err.message.length > 0 ? err.message : err && typeof err.toString === "function" ? String(err) : "Unknown render error";
      const stack = err && typeof err.stack === "string" ? err.stack.split("\n").slice(0, 6).join("\n") : "";
      return /* @__PURE__ */ jsxs("div", { className: "rounded-lg border border-ui-border-error bg-ui-bg-subtle p-4 text-ui-fg-base", children: [
        /* @__PURE__ */ jsx("div", { className: "text-xs font-semibold uppercase tracking-wider text-ui-fg-error", children: this.props.label }),
        /* @__PURE__ */ jsx("div", { className: "mt-1 text-xs text-ui-fg-subtle", children: "Widget zlyhal pri renderingu — zvyšok stránky funguje." }),
        /* @__PURE__ */ jsx("div", { className: "mt-2 text-xs font-mono text-ui-fg-base whitespace-pre-wrap break-all", children: message }),
        stack ? /* @__PURE__ */ jsxs("details", { className: "mt-2", children: [
          /* @__PURE__ */ jsx("summary", { className: "text-xs cursor-pointer text-ui-fg-subtle", children: "Stack" }),
          /* @__PURE__ */ jsx("pre", { className: "mt-1 text-[10px] font-mono text-ui-fg-subtle whitespace-pre-wrap break-all", children: stack })
        ] }) : null
      ] });
    }
    return this.props.children;
  }
}
const withWidgetBoundary = (WidgetComponent, label) => {
  const Wrapped = (props) => /* @__PURE__ */ jsx(WidgetBoundary, { label, children: /* @__PURE__ */ jsx(AdminQueryProvider, { children: /* @__PURE__ */ jsx(WidgetComponent, { ...props }) }) });
  Wrapped.displayName = `WithWidgetBoundary(${label})`;
  return Wrapped;
};
const withRouteBoundary = (PageComponent, label) => {
  const Wrapped = (props) => /* @__PURE__ */ jsx(WidgetBoundary, { label, children: /* @__PURE__ */ jsx(AdminQueryProvider, { children: /* @__PURE__ */ jsx(PageComponent, { ...props }) }) });
  Wrapped.displayName = `WithRouteBoundary(${label})`;
  return Wrapped;
};
const EN = {
  checks: {
    "title-presence": "SEO title length",
    "title-keyphrase": "Keyphrase in title",
    "keyphrase-title-position": "Keyphrase near the start of the title",
    "meta-description-presence": "Meta description length",
    "meta-description-keyphrase": "Keyphrase in meta description",
    "keyphrase-slug": "Keyphrase in the URL",
    "word-count": "Description length",
    "keyphrase-length": "Keyphrase length",
    "keyphrase-density": "Keyphrase density",
    "keyphrase-introduction": "Keyphrase in the first paragraph",
    "keyphrase-distribution": "Keyphrase distribution",
    "keyphrase-even-distribution": "Even keyphrase distribution",
    "paragraph-length": "Paragraph length",
    "sentence-length": "Sentence length",
    "url-length": "URL length",
    "canonical-url": "Canonical URL",
    "media-count": "Product images"
  },
  groups: {
    basic: "Basic SEO",
    keyphrase: "Keyphrase",
    readability: "Readability",
    technical: "Technical"
  },
  bands: { good: "Good", ok: "Fair", poor: "Poor" },
  ui: {
    scoreHeading: "SEO score",
    listHeading: "SEO scores",
    listSubtitle: "Every published product, weakest first.",
    recalculate: "Recalculate",
    searchPlaceholder: "Search by name or handle…",
    columnProduct: "Product",
    columnKeyphrase: "Keyphrase",
    columnIssues: "To fix",
    columnScore: "Score",
    noResults: "No results.",
    noKeyphrase: "not set",
    products: "products",
    average: "average",
    focusKeyphrase: "Focus keyphrase",
    keyphrasePlaceholder: "e.g. adjustable dumbbells",
    save: "Save",
    saved: "Keyphrase saved.",
    saveFailed: "Could not save",
    keyphraseHint: "Without a keyphrase the keyphrase checks are left out of the score.",
    keyphraseSourceOnly: "The keyphrase is edited in the source language; translate it with the rest of the copy.",
    issues: "to fix",
    checks: "checks",
    loadFailed: "Could not load the score.",
    googlePreview: "Google preview",
    desktop: "Desktop",
    mobile: "Mobile",
    noTitle: "No title",
    noDescription: "No meta description.",
    title: "Title",
    description: "Description",
    language: "Language",
    meterMissing: "missing",
    meterShort: "short",
    meterGood: "good",
    meterTruncated: "truncated",
    recommendedMinimum: "Recommended minimum"
  }
};
const HU = {
  checks: {
    "title-presence": "SEO cím hossza",
    "title-keyphrase": "Kulcsszó a címben",
    "keyphrase-title-position": "Kulcsszó a cím elején",
    "meta-description-presence": "Meta leírás hossza",
    "meta-description-keyphrase": "Kulcsszó a meta leírásban",
    "keyphrase-slug": "Kulcsszó az URL-ben",
    "word-count": "Leírás hossza",
    "keyphrase-length": "Kulcsszó hossza",
    "keyphrase-density": "Kulcsszó sűrűsége",
    "keyphrase-introduction": "Kulcsszó az első bekezdésben",
    "keyphrase-distribution": "Kulcsszó eloszlása",
    "keyphrase-even-distribution": "Kulcsszó egyenletes eloszlása",
    "paragraph-length": "Bekezdések hossza",
    "sentence-length": "Mondatok hossza",
    "url-length": "URL hossza",
    "canonical-url": "Kanonikus URL",
    "media-count": "Termékképek száma"
  },
  groups: {
    basic: "Alap SEO",
    keyphrase: "Kulcsszó",
    readability: "Olvashatóság",
    technical: "Technikai"
  },
  bands: { good: "Jó", ok: "Elmegy", poor: "Gyenge" },
  ui: {
    scoreHeading: "SEO pontszám",
    listHeading: "SEO pontszámok",
    listSubtitle: "Minden publikált termék pontszáma, a leggyengébbek elöl.",
    recalculate: "Újraszámolás",
    searchPlaceholder: "Keresés név vagy handle szerint…",
    columnProduct: "Termék",
    columnKeyphrase: "Kulcsszó",
    columnIssues: "Javítanivaló",
    columnScore: "Pontszám",
    noResults: "Nincs találat.",
    noKeyphrase: "nincs beállítva",
    products: "termék",
    average: "átlag",
    focusKeyphrase: "Fókusz kulcsszó",
    keyphrasePlaceholder: "pl. posilňovacie stroje",
    save: "Mentés",
    saved: "Kulcsszó mentve.",
    saveFailed: "Mentés sikertelen",
    keyphraseHint: "Kulcsszó nélkül a kulcsszavas ellenőrzések kimaradnak a pontszámból.",
    keyphraseSourceOnly: "A kulcsszót a forrásnyelven lehet szerkeszteni; a fordítását a többi szöveggel együtt add meg.",
    issues: "javítanivaló",
    checks: "ellenőrzés",
    loadFailed: "Nem sikerült betölteni a pontszámot.",
    googlePreview: "Google előnézet",
    desktop: "Asztali",
    mobile: "Mobil",
    noTitle: "Nincs cím",
    noDescription: "Nincs meta leírás.",
    title: "Cím",
    description: "Leírás",
    language: "Nyelv",
    meterMissing: "hiányzik",
    meterShort: "rövid",
    meterGood: "jó",
    meterTruncated: "levágva",
    recommendedMinimum: "Ajánlott minimum"
  }
};
const SK = {
  checks: {
    "title-presence": "Dĺžka SEO titulku",
    "title-keyphrase": "Kľúčová fráza v titulku",
    "keyphrase-title-position": "Kľúčová fráza na začiatku titulku",
    "meta-description-presence": "Dĺžka meta popisu",
    "meta-description-keyphrase": "Kľúčová fráza v meta popise",
    "keyphrase-slug": "Kľúčová fráza v URL",
    "word-count": "Dĺžka popisu",
    "keyphrase-length": "Dĺžka kľúčovej frázy",
    "keyphrase-density": "Hustota kľúčovej frázy",
    "keyphrase-introduction": "Kľúčová fráza v prvom odseku",
    "keyphrase-distribution": "Rozloženie kľúčovej frázy",
    "keyphrase-even-distribution": "Rovnomerné rozloženie kľúčovej frázy",
    "paragraph-length": "Dĺžka odsekov",
    "sentence-length": "Dĺžka viet",
    "url-length": "Dĺžka URL",
    "canonical-url": "Kanonická URL",
    "media-count": "Počet obrázkov produktu"
  },
  groups: {
    basic: "Základné SEO",
    keyphrase: "Kľúčová fráza",
    readability: "Čitateľnosť",
    technical: "Technické"
  },
  bands: { good: "Dobré", ok: "Priemerné", poor: "Slabé" },
  ui: {
    scoreHeading: "SEO skóre",
    listHeading: "SEO skóre",
    listSubtitle: "Každý publikovaný produkt, najslabšie navrchu.",
    recalculate: "Prepočítať",
    searchPlaceholder: "Hľadať podľa názvu alebo handle…",
    columnProduct: "Produkt",
    columnKeyphrase: "Kľúčová fráza",
    columnIssues: "Na opravu",
    columnScore: "Skóre",
    noResults: "Žiadne výsledky.",
    noKeyphrase: "nenastavené",
    products: "produktov",
    average: "priemer",
    focusKeyphrase: "Hlavná kľúčová fráza",
    keyphrasePlaceholder: "napr. posilňovacie stroje",
    save: "Uložiť",
    saved: "Kľúčová fráza uložená.",
    saveFailed: "Uloženie zlyhalo",
    keyphraseHint: "Bez kľúčovej frázy sa kontroly kľúčovej frázy do skóre nezapočítajú.",
    keyphraseSourceOnly: "Kľúčová fráza sa upravuje v zdrojovom jazyku; jej preklad zadaj spolu s ostatnými textami.",
    issues: "na opravu",
    checks: "kontrol",
    loadFailed: "Skóre sa nepodarilo načítať.",
    googlePreview: "Náhľad Google",
    desktop: "Počítač",
    mobile: "Mobil",
    noTitle: "Bez titulku",
    noDescription: "Bez meta popisu.",
    title: "Titulok",
    description: "Popis",
    language: "Jazyk",
    meterMissing: "chýba",
    meterShort: "krátke",
    meterGood: "dobré",
    meterTruncated: "odrezané",
    recommendedMinimum: "Odporúčané minimum"
  }
};
const PACKS = { en: EN, hu: HU, sk: SK };
const labelsFor = (lang) => PACKS[lang] ?? EN;
const FALLBACK_LABELS = labelsFor("en");
const GROUP_ORDER = ["basic", "keyphrase", "readability", "technical"];
const BAND_HEX = {
  good: "#3b9c5a",
  ok: "#d98f2b",
  poor: "#cd3a3a"
};
const BAND_COLOR = {
  good: "green",
  ok: "orange",
  poor: "red"
};
const LocaleTabs = ({
  locales,
  active,
  onSelect,
  label
}) => {
  if (locales.length < 2) return null;
  return /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2", children: [
    /* @__PURE__ */ jsx("span", { className: "txt-compact-xsmall text-ui-fg-muted", children: label }),
    /* @__PURE__ */ jsx("div", { className: "bg-ui-bg-component flex rounded-full p-0.5", children: locales.map((locale) => /* @__PURE__ */ jsx(
      "button",
      {
        type: "button",
        onClick: () => onSelect(locale),
        "aria-pressed": locale === active,
        className: `txt-compact-xsmall rounded-full px-2.5 py-0.5 uppercase transition-colors ${locale === active ? "bg-ui-bg-base text-ui-fg-base shadow-elevation-card-rest" : "text-ui-fg-muted hover:text-ui-fg-subtle"}`,
        children: locale
      },
      locale
    )) })
  ] });
};
const localeQuery = (locale, extra = {}) => {
  const params = new URLSearchParams(locale ? { locale, ...extra } : extra);
  const query = params.toString();
  return query ? `?${query}` : "";
};
const TITLE_LIMIT = 60;
const TITLE_MIN = 50;
const DESCRIPTION_LIMIT = 155;
const DESCRIPTION_MIN = 120;
const SERP = {
  surface: "#ffffff",
  border: "#dadce0",
  favicon: "#f1f3f4",
  siteName: "#202124",
  url: "#4d5156",
  title: "#1a0dab",
  snippet: "#474747",
  font: "arial, sans-serif"
};
const statusHex = (check) => check.score >= check.maxScore ? BAND_HEX.good : check.score > 0 ? BAND_HEX.ok : BAND_HEX.poor;
const resolveProductId = () => {
  var _a, _b;
  if (typeof window === "undefined") return null;
  const parts = window.location.pathname.split("/products/");
  if (parts.length < 2) return null;
  return ((_b = (_a = parts[1]) == null ? void 0 : _a.split("/")[0]) == null ? void 0 : _b.split("?")[0]) ?? null;
};
const ScoreGauge = ({ score, band }) => {
  const radius = 34;
  const circumference = 2 * Math.PI * radius;
  const filled = Math.min(Math.max(score, 0), 100) / 100 * circumference;
  return /* @__PURE__ */ jsxs("div", { className: "relative h-[84px] w-[84px] shrink-0", children: [
    /* @__PURE__ */ jsxs("svg", { viewBox: "0 0 84 84", className: "h-full w-full -rotate-90", children: [
      /* @__PURE__ */ jsx(
        "circle",
        {
          cx: "42",
          cy: "42",
          r: radius,
          fill: "none",
          strokeWidth: "8",
          className: "stroke-ui-border-base"
        }
      ),
      /* @__PURE__ */ jsx(
        "circle",
        {
          cx: "42",
          cy: "42",
          r: radius,
          fill: "none",
          strokeWidth: "8",
          strokeLinecap: "round",
          stroke: BAND_HEX[band],
          strokeDasharray: `${filled} ${circumference}`
        }
      )
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "absolute inset-0 flex flex-col items-center justify-center", children: [
      /* @__PURE__ */ jsx("span", { className: "txt-compact-large-plus leading-none", children: score }),
      /* @__PURE__ */ jsx("span", { className: "text-ui-fg-muted text-[10px] leading-tight", children: "/ 100" })
    ] })
  ] });
};
const meterState = (len, min, limit) => len === 0 ? "empty" : len > limit ? "over" : len < min ? "short" : "good";
const METER_HEX = {
  empty: BAND_HEX.poor,
  short: BAND_HEX.ok,
  good: BAND_HEX.good,
  over: BAND_HEX.ok
};
const MetaMeter = ({
  label,
  value,
  min,
  limit,
  labels
}) => {
  const len = value.length;
  const state = meterState(len, min, limit);
  const hex = METER_HEX[state];
  const note = {
    empty: labels.ui.meterMissing,
    short: labels.ui.meterShort,
    good: labels.ui.meterGood,
    over: labels.ui.meterTruncated
  };
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-1.5", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-baseline justify-between gap-2", children: [
      /* @__PURE__ */ jsx(Text, { size: "xsmall", className: "text-ui-fg-subtle", children: label }),
      /* @__PURE__ */ jsxs(Text, { size: "xsmall", className: "tabular-nums", style: { color: hex }, children: [
        len,
        " / ",
        limit,
        " · ",
        note[state]
      ] })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "bg-ui-bg-component relative h-1.5 w-full overflow-hidden rounded-full", children: [
      /* @__PURE__ */ jsx(
        "div",
        {
          className: "h-full rounded-full transition-[width] duration-300",
          style: {
            width: `${Math.min(100, Math.round(len / limit * 100))}%`,
            backgroundColor: hex
          }
        }
      ),
      /* @__PURE__ */ jsx(
        "span",
        {
          className: "absolute inset-y-0 w-px opacity-40",
          style: { left: `${Math.round(min / limit * 100)}%`, backgroundColor: SERP.url },
          title: `${labels.ui.recommendedMinimum}: ${min}`
        }
      )
    ] })
  ] });
};
const SerpPreview = ({ meta, labels }) => {
  const [device, setDevice] = useState("desktop");
  const isMobile = device === "mobile";
  const deviceLabel = {
    desktop: labels.ui.desktop,
    mobile: labels.ui.mobile
  };
  const parts = meta.url.replace(/^https?:\/\//, "").split("/").filter(Boolean);
  const host = parts[0] ?? "";
  const breadcrumb = parts.join(" › ");
  const initial = host.replace(/^www\./, "").charAt(0).toUpperCase() || "?";
  return /* @__PURE__ */ jsxs("div", { className: "bg-ui-bg-subtle flex flex-col gap-3 rounded-lg p-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsx(Text, { size: "xsmall", weight: "plus", className: "text-ui-fg-muted uppercase", children: labels.ui.googlePreview }),
      /* @__PURE__ */ jsx("div", { className: "bg-ui-bg-component flex rounded-full p-0.5", children: ["desktop", "mobile"].map((d) => /* @__PURE__ */ jsx(
        "button",
        {
          type: "button",
          onClick: () => setDevice(d),
          className: `txt-compact-xsmall rounded-full px-2 py-0.5 transition-colors ${device === d ? "bg-ui-bg-base text-ui-fg-base shadow-elevation-card-rest" : "text-ui-fg-muted hover:text-ui-fg-subtle"}`,
          children: deviceLabel[d]
        },
        d
      )) })
    ] }),
    /* @__PURE__ */ jsxs(
      "div",
      {
        className: "group mx-auto w-full rounded-xl p-4 shadow-elevation-card-rest",
        style: {
          backgroundColor: SERP.surface,
          border: `1px solid ${SERP.border}`,
          fontFamily: SERP.font,
          maxWidth: isMobile ? 380 : 600
        },
        children: [
          /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsx(
              "span",
              {
                className: "flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[13px] font-medium",
                style: {
                  backgroundColor: SERP.favicon,
                  border: `1px solid ${SERP.border}`,
                  color: SERP.siteName
                },
                children: initial
              }
            ),
            /* @__PURE__ */ jsxs("div", { className: "min-w-0 flex-1 leading-tight", children: [
              /* @__PURE__ */ jsx("div", { className: "truncate text-[14px]", style: { color: SERP.siteName }, children: host || "—" }),
              /* @__PURE__ */ jsx("div", { className: "truncate text-[12px]", style: { color: SERP.url }, title: meta.url, children: breadcrumb || "—" })
            ] })
          ] }),
          /* @__PURE__ */ jsx(
            "div",
            {
              className: "mt-2 overflow-hidden group-hover:underline",
              style: {
                color: SERP.title,
                fontSize: isMobile ? 18 : 20,
                lineHeight: "1.3",
                display: "-webkit-box",
                WebkitLineClamp: isMobile ? 2 : 1,
                WebkitBoxOrient: "vertical"
              },
              title: meta.title,
              children: meta.title || labels.ui.noTitle
            }
          ),
          /* @__PURE__ */ jsx(
            "div",
            {
              className: "mt-1.5 overflow-hidden text-[14px]",
              style: {
                color: SERP.snippet,
                lineHeight: "1.58",
                display: "-webkit-box",
                WebkitLineClamp: isMobile ? 3 : 2,
                WebkitBoxOrient: "vertical"
              },
              title: meta.description,
              children: meta.description || labels.ui.noDescription
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2.5", children: [
      /* @__PURE__ */ jsx(
        MetaMeter,
        {
          label: labels.ui.title,
          value: meta.title,
          min: TITLE_MIN,
          limit: TITLE_LIMIT,
          labels
        }
      ),
      /* @__PURE__ */ jsx(
        MetaMeter,
        {
          label: labels.ui.description,
          value: meta.description,
          min: DESCRIPTION_MIN,
          limit: DESCRIPTION_LIMIT,
          labels
        }
      )
    ] })
  ] });
};
const ProductSeoScoreWidget = ({ data }) => {
  const productId = (data == null ? void 0 : data.id) ?? resolveProductId();
  const [score, setScore] = useState(null);
  const [loadError, setLoadError] = useState(null);
  const [keyphrase, setKeyphrase] = useState("");
  const [savedKeyphrase, setSavedKeyphrase] = useState("");
  const [saving, setSaving] = useState(false);
  const [locale, setLocale] = useState("");
  const [locales, setLocales] = useState([]);
  const [sourceLocale, setSourceLocale] = useState("");
  const [labels, setLabels] = useState(FALLBACK_LABELS);
  const load = useCallback(async () => {
    if (!productId) return;
    try {
      const res = await fetch(`/admin/seo-score/${productId}${localeQuery(locale)}`, {
        credentials: "include"
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const body = await res.json();
      setScore(body.score);
      setLocales(body.locales ?? []);
      setSourceLocale(body.source_locale ?? "");
      if (body.labels) setLabels(body.labels);
      setKeyphrase(body.score.keyphrase ?? "");
      setSavedKeyphrase(body.score.keyphrase ?? "");
      setLoadError(null);
    } catch (e) {
      setLoadError(e instanceof Error ? e.message : FALLBACK_LABELS.ui.loadFailed);
    }
  }, [productId, locale]);
  useEffect(() => {
    load();
  }, [load]);
  const active = (score == null ? void 0 : score.locale) ?? locale;
  const editable = !sourceLocale || active === sourceLocale;
  const saveKeyphrase = async () => {
    if (!productId) return;
    setSaving(true);
    try {
      const res = await fetch(`/admin/products/${productId}`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ metadata: { seo_keyphrase: keyphrase.trim() || null } })
      });
      if (!res.ok) throw new Error((await res.text()).slice(0, 200) || `HTTP ${res.status}`);
      setSavedKeyphrase(keyphrase.trim());
      toast.success(labels.ui.saved);
      await load();
    } catch (e) {
      toast.error(`${labels.ui.saveFailed}: ${e instanceof Error ? e.message : "—"}`);
    } finally {
      setSaving(false);
    }
  };
  return /* @__PURE__ */ jsxs(Container, { className: "divide-y p-0", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-4 px-6 py-4", children: [
      /* @__PURE__ */ jsx(Heading, { level: "h2", children: labels.ui.scoreHeading }),
      /* @__PURE__ */ jsx(
        LocaleTabs,
        {
          locales,
          active,
          onSelect: setLocale,
          label: labels.ui.language
        }
      )
    ] }),
    loadError && /* @__PURE__ */ jsx("div", { className: "px-6 py-4", children: /* @__PURE__ */ jsx(Text, { className: "text-ui-fg-error", children: loadError }) }),
    score && /* @__PURE__ */ jsxs("div", { className: "grid grid-cols-1 gap-6 px-6 py-5 lg:grid-cols-5", children: [
      /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-5 lg:col-span-3", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsx(ScoreGauge, { score: score.score, band: score.band }),
          /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-0.5", children: [
            /* @__PURE__ */ jsx(Text, { weight: "plus", children: labels.bands[score.band] }),
            /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle", children: [
              score.issues,
              " ",
              labels.ui.issues,
              " · ",
              score.checks.length,
              " ",
              labels.ui.checks
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
          /* @__PURE__ */ jsx(Label, { htmlFor: "seo-keyphrase", children: labels.ui.focusKeyphrase }),
          /* @__PURE__ */ jsxs("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsx(
              Input,
              {
                id: "seo-keyphrase",
                placeholder: labels.ui.keyphrasePlaceholder,
                value: keyphrase,
                disabled: !editable,
                onChange: (e) => setKeyphrase(e.target.value),
                onKeyDown: (e) => {
                  if (e.key === "Enter" && !saving && editable) saveKeyphrase();
                }
              }
            ),
            /* @__PURE__ */ jsx(
              Button,
              {
                variant: "secondary",
                onClick: saveKeyphrase,
                isLoading: saving,
                disabled: saving || !editable || keyphrase.trim() === savedKeyphrase,
                children: labels.ui.save
              }
            )
          ] }),
          !editable ? /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: labels.ui.keyphraseSourceOnly }) : !savedKeyphrase && /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-subtle", children: labels.ui.keyphraseHint })
        ] }),
        /* @__PURE__ */ jsx("div", { className: "flex flex-col gap-4", children: GROUP_ORDER.map((group) => {
          const items = score.checks.filter((c) => c.group === group);
          if (!items.length) return null;
          return /* @__PURE__ */ jsxs("div", { className: "flex flex-col gap-2", children: [
            /* @__PURE__ */ jsx(Text, { size: "xsmall", weight: "plus", className: "text-ui-fg-muted uppercase", children: labels.groups[group] }),
            items.map((c) => /* @__PURE__ */ jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsx(
                "span",
                {
                  className: "mt-1.5 inline-block h-1.5 w-1.5 shrink-0 rounded-full",
                  style: { backgroundColor: statusHex(c) }
                }
              ),
              /* @__PURE__ */ jsxs("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between gap-3", children: [
                  /* @__PURE__ */ jsx(Text, { size: "small", weight: "plus", children: c.label }),
                  /* @__PURE__ */ jsxs(Text, { size: "xsmall", className: "text-ui-fg-muted shrink-0", children: [
                    c.score,
                    "/",
                    c.maxScore
                  ] })
                ] }),
                c.detail && /* @__PURE__ */ jsx(Text, { size: "xsmall", className: "text-ui-fg-subtle", children: c.detail })
              ] })
            ] }, c.id))
          ] }, group);
        }) })
      ] }),
      /* @__PURE__ */ jsx("div", { className: "lg:col-span-2", children: /* @__PURE__ */ jsx(SerpPreview, { meta: score.meta, labels }) })
    ] })
  ] });
};
defineWidgetConfig({ zone: "product.details.after" });
const WidgetComponent0 = withWidgetBoundary(ProductSeoScoreWidget, "SEO score");
const SeoScorePage = () => {
  const [rows, setRows] = useState([]);
  const [count, setCount] = useState(0);
  const [average, setAverage] = useState(0);
  const [search, setSearch] = useState("");
  const [debounced, setDebounced] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [locale, setLocale] = useState("");
  const [locales, setLocales] = useState([]);
  const [active, setActive] = useState("");
  const [labels, setLabels] = useState(FALLBACK_LABELS);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(search), 300);
    return () => clearTimeout(t);
  }, [search]);
  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(
        `/admin/seo-score${localeQuery(locale, debounced ? { q: debounced } : {})}`,
        { credentials: "include" }
      );
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const body = await res.json();
      setRows(body.scores ?? []);
      setCount(body.count ?? 0);
      setAverage(body.average ?? 0);
      setLocales(body.locales ?? []);
      setActive(body.locale ?? "");
      if (body.labels) setLabels(body.labels);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : FALLBACK_LABELS.ui.loadFailed);
    } finally {
      setLoading(false);
    }
  }, [debounced, locale]);
  useEffect(() => {
    load();
  }, [load]);
  return /* @__PURE__ */ jsxs(Container, { className: "flex flex-col gap-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex items-start justify-between gap-4", children: [
      /* @__PURE__ */ jsxs("div", { children: [
        /* @__PURE__ */ jsx(Heading, { level: "h1", children: labels.ui.listHeading }),
        /* @__PURE__ */ jsx(Text, { className: "text-ui-fg-subtle", children: labels.ui.listSubtitle })
      ] }),
      /* @__PURE__ */ jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsx(
          LocaleTabs,
          {
            locales,
            active,
            onSelect: setLocale,
            label: labels.ui.language
          }
        ),
        count > 0 && /* @__PURE__ */ jsxs(Text, { size: "small", className: "text-ui-fg-subtle", children: [
          count,
          " ",
          labels.ui.products,
          " · ",
          labels.ui.average,
          " ",
          average,
          "/100"
        ] }),
        /* @__PURE__ */ jsx(Button, { variant: "secondary", onClick: load, isLoading: loading, disabled: loading, children: labels.ui.recalculate })
      ] })
    ] }),
    /* @__PURE__ */ jsx(
      Input,
      {
        placeholder: labels.ui.searchPlaceholder,
        value: search,
        onChange: (e) => setSearch(e.target.value)
      }
    ),
    error && /* @__PURE__ */ jsx(Text, { className: "text-ui-fg-error", children: error }),
    /* @__PURE__ */ jsxs(Table, { children: [
      /* @__PURE__ */ jsx(Table.Header, { children: /* @__PURE__ */ jsxs(Table.Row, { children: [
        /* @__PURE__ */ jsx(Table.HeaderCell, { children: labels.ui.columnProduct }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { children: labels.ui.columnKeyphrase }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { children: labels.ui.columnIssues }),
        /* @__PURE__ */ jsx(Table.HeaderCell, { children: labels.ui.columnScore })
      ] }) }),
      /* @__PURE__ */ jsx(Table.Body, { children: rows.map((r) => /* @__PURE__ */ jsxs(Table.Row, { children: [
        /* @__PURE__ */ jsx(Table.Cell, { children: /* @__PURE__ */ jsx(
          "a",
          {
            href: `/app/products/${r.product_id}`,
            className: "text-ui-fg-interactive hover:underline",
            children: r.title || r.handle
          }
        ) }),
        /* @__PURE__ */ jsx(Table.Cell, { children: r.keyphrase ? /* @__PURE__ */ jsx(Text, { size: "small", children: r.keyphrase }) : /* @__PURE__ */ jsx(Text, { size: "small", className: "text-ui-fg-muted", children: labels.ui.noKeyphrase }) }),
        /* @__PURE__ */ jsx(Table.Cell, { children: r.issues }),
        /* @__PURE__ */ jsx(Table.Cell, { children: /* @__PURE__ */ jsxs(Badge, { color: BAND_COLOR[r.band], children: [
          r.score,
          "/100"
        ] }) })
      ] }, r.product_id)) })
    ] }),
    !loading && !rows.length && !error && /* @__PURE__ */ jsx(Text, { className: "text-ui-fg-subtle", children: labels.ui.noResults })
  ] });
};
const config = defineRouteConfig({ label: "SEO scores", icon: ChartBar });
const RouteComponent0 = withRouteBoundary(SeoScorePage, "SEO scores");
const widgetModule = { widgets: [
  {
    Component: WidgetComponent0,
    zone: ["product.details.after"]
  }
] };
const routeModule = {
  routes: [
    {
      Component: RouteComponent0,
      path: "/seo-score"
    }
  ]
};
const menuItemModule = {
  menuItems: [
    {
      label: config.label,
      icon: config.icon,
      path: "/seo-score",
      nested: void 0,
      rank: void 0,
      translationNs: void 0
    }
  ]
};
const formModule = { customFields: {} };
const displayModule = {
  displays: {}
};
const i18nModule = { resources: {} };
const plugin = {
  widgetModule,
  routeModule,
  menuItemModule,
  formModule,
  displayModule,
  i18nModule
};
export {
  plugin as default
};
